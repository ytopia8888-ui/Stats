# SkyTint Native Root Overlay — StandRise Rework

Нативный Android GUI без HTML. Целевой пакет игры: `com.standrise.game`.

## Важно
Это исходный Android Studio проект, а не готовый APK. Скрипт из `/data/local/tmp/` не может сам нарисовать Android overlay: для панели нужен установленный APK с `SYSTEM_ALERT_WINDOW`.

Панель отображается поверх приложений, её можно перетаскивать, сворачивать и закрывать. Есть профили Blue/Sunset/Violet/Mint/Night/Gold, ползунок интенсивности и сохранение JSON-профиля.

**Честное ограничение:** этот проект пока не внедряет цвет в Unity-рендерер игры. Профиль сохраняется отдельно и сам по себе не изменит небо в игре. Для этого нужен отдельный доказанный hook/патч игры.

## Сборка
1. Открой папку проекта в Android Studio.
2. Используй JDK 17 и Android SDK Platform 35.
3. Выполни `Build > Build APK(s)`.
4. Установи `app/build/outputs/apk/debug/app-debug.apk` на телефон.

## Запуск с root
Скопируй `scripts/launch_skytint.sh` на телефон как `/data/local/tmp/launch_skytint.sh`, затем:
```sh
su -c 'chmod 755 /data/local/tmp/launch_skytint.sh'
su -c 'sh /data/local/tmp/launch_skytint.sh'
```
При первом запуске Android может потребовать вручную разрешить «Поверх других приложений» для SkyTint Overlay.

## Где сохраняется профиль
В приватной папке приложения:
`/sdcard/Android/data/com.skytint.overlay/files/SkyTintStandRise/sky_config.json`
