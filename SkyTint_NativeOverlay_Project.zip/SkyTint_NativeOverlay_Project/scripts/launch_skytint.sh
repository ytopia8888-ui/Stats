#!/system/bin/sh
# Run as root, e.g. su -c 'sh /data/local/tmp/launch_skytint.sh'
PKG='com.skytint.overlay'
GAME='com.standrise.game'
if ! pm path "$PKG" >/dev/null 2>&1; then
  echo "SkyTint Overlay APK не установлен: сначала собери и установи app-debug.apk."
  exit 1
fi
# Grant overlay app-op if Android build permits it; user may still need to confirm Settings.
cmd appops set "$PKG" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || appops set "$PKG" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1
am start -n "$PKG/.MainActivity" >/dev/null 2>&1
sleep 2
if pm path "$GAME" >/dev/null 2>&1; then
  monkey -p "$GAME" 1 >/dev/null 2>&1
else
  echo "Не найдена игра $GAME"
fi
