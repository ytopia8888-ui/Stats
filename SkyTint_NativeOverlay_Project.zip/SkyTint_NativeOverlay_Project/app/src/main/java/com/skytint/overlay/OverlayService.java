package com.skytint.overlay;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.FileWriter;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;
    private int skyColor = Color.rgb(75, 155, 255);
    private int fogColor = Color.rgb(175, 205, 230);
    private int intensity = 100;
    private TextView status;

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        buildPanel();
    }
    private void createNotification() {
        String channel = "skytint_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channel, "SkyTint Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
        b.setContentTitle("SkyTint Overlay активен").setContentText("Плавающая панель для StandRise Rework")
         .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true);
        startForeground(77, b.build());
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); d.setStroke(1, Color.argb(150,255,255,255));
        return d;
    }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.WHITE); t.setPadding(8,8,8,8); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false);
        return b;
    }
    private void buildPanel() {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(10,8,10,10); card.setBackground(bg(Color.rgb(24,30,43), 24));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("SkyTint  •  StandRise", 15); title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        Button hide = button("—"); header.addView(hide);
        Button close = button("×"); header.addView(close);
        card.addView(header);
        status = text("Профиль: Blue • ещё не применён к рендерингу", 11); card.addView(status);
        card.addView(text("Цвет неба", 13));
        LinearLayout presets = new LinearLayout(this); presets.setOrientation(LinearLayout.HORIZONTAL);
        addPreset(presets,"Blue",Color.rgb(75,155,255),Color.rgb(175,205,230));
        addPreset(presets,"Sunset",Color.rgb(255,105,65),Color.rgb(255,180,120));
        addPreset(presets,"Violet",Color.rgb(145,80,255),Color.rgb(190,160,230));
        card.addView(presets);
        LinearLayout presets2 = new LinearLayout(this); presets2.setOrientation(LinearLayout.HORIZONTAL);
        addPreset(presets2,"Mint",Color.rgb(55,220,180),Color.rgb(150,230,215));
        addPreset(presets2,"Night",Color.rgb(15,25,70),Color.rgb(50,60,100));
        addPreset(presets2,"Gold",Color.rgb(255,195,55),Color.rgb(255,220,145));
        card.addView(presets2);
        card.addView(text("Интенсивность профиля", 13));
        SeekBar seek = new SeekBar(this); seek.setMax(100); seek.setProgress(intensity); card.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean u) { intensity=p; }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { saveConfig(); status.setText("Интенсивность: "+intensity+"% • профиль сохранён"); }
        });
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save = button("Сохранить профиль"); actions.addView(save,new LinearLayout.LayoutParams(0,-2,1));
        Button reset = button("Сброс"); actions.addView(reset,new LinearLayout.LayoutParams(0,-2,1));
        card.addView(actions);
        save.setOnClickListener(v -> saveConfig());
        reset.setOnClickListener(v -> { skyColor=Color.rgb(75,155,255); fogColor=Color.rgb(175,205,230); intensity=100; seek.setProgress(100); status.setText("Профиль сброшен"); saveConfig(); });
        hide.setOnClickListener(v -> { if (card.getChildCount()>1) { for(int i=1;i<card.getChildCount();i++) card.getChildAt(i).setVisibility(View.GONE); hide.setText("+"); } else {} });
        hide.setOnClickListener(v -> toggleCollapsed(card, hide));
        close.setOnClickListener(v -> stopSelf());
        params = new WindowManager.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.88f),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; params.y = 80;
        header.setOnTouchListener(new View.OnTouchListener() {
            int startX,startY; float downX,downY;
            public boolean onTouch(View v, MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){startX=params.x;startY=params.y;downX=e.getRawX();downY=e.getRawY();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=startX+(int)(e.getRawX()-downX);params.y=startY+(int)(e.getRawY()-downY);wm.updateViewLayout(panel,params);return true;}
                return e.getAction()==MotionEvent.ACTION_UP;
            }
        });
        panel=card; wm.addView(panel,params);
    }
    private void toggleCollapsed(LinearLayout card, Button toggle) {
        boolean collapse = toggle.getText().toString().equals("—");
        for(int i=1;i<card.getChildCount();i++) card.getChildAt(i).setVisibility(collapse?View.GONE:View.VISIBLE);
        toggle.setText(collapse?"+":"—");
        params.height=WindowManager.LayoutParams.WRAP_CONTENT; wm.updateViewLayout(panel,params);
    }
    private void addPreset(LinearLayout row,String name,int sky,int fog) {
        Button b=button(name); b.setBackground(bg(sky,16)); b.setTextColor(Color.WHITE);
        row.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        b.setOnClickListener(v -> { skyColor=sky; fogColor=fog; status.setText("Выбран профиль: "+name+" • нажми «Сохранить профиль»"); });
    }
    private void saveConfig() {
        try {
            File dir = new File(getExternalFilesDir(null), "SkyTintStandRise");
            if(!dir.exists()) dir.mkdirs();
            JSONObject o=new JSONObject();
            o.put("targetPackage","com.standrise.game");
            o.put("skyColor",String.format("#%06X",0xFFFFFF & skyColor));
            o.put("fogColor",String.format("#%06X",0xFFFFFF & fogColor));
            o.put("intensity",intensity);
            o.put("note","Profile only: game renderer hook not implemented");
            File f=new File(dir,"sky_config.json");
            FileWriter w=new FileWriter(f); w.write(o.toString(2)); w.close();
            status.setText("Профиль сохранён в Android/data/com.skytint.overlay/files/SkyTintStandRise/");
            Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this,"Ошибка сохранения: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_NOT_STICKY;}
    @Override public void onDestroy(){ if(wm!=null && panel!=null) try{wm.removeView(panel);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
