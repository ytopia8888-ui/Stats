package com.skytint.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 702;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(20, 25, 36));
        TextView title = new TextView(this);
        title.setText("SkyTint • StandRise Rework");
        title.setTextColor(Color.WHITE); title.setTextSize(22);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("\nНативная плавающая панель. Выдай разрешение «Поверх других приложений».\n\nВажно: это GUI-профиль; сам по себе он не меняет Unity-небо в игре.");
        info.setTextColor(Color.LTGRAY); info.setTextSize(15);
        root.addView(info);
        Button start = new Button(this); start.setText("Разрешить и открыть панель");
        root.addView(start);
        Button stop = new Button(this); stop.setText("Закрыть панель");
        root.addView(stop);
        setContentView(root);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQ_OVERLAY);
            } else startOverlayAndGame();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_OVERLAY && Settings.canDrawOverlays(this)) startOverlayAndGame();
    }
    private void startOverlayAndGame() {
        startService(new Intent(this, OverlayService.class));
        Intent game = getPackageManager().getLaunchIntentForPackage("com.standrise.game");
        if (game != null) {
            game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(game);
        }
        finish();
    }
}
