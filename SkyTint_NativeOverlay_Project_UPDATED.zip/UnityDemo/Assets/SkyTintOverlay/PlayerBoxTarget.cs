using UnityEngine;

/// <summary>Attach to a character root in your own Unity test scene.</summary>
public sealed class PlayerBoxTarget : MonoBehaviour
{
    [Tooltip("Optional. If empty, child renderers are used to calculate the bounds.")]
    public Renderer[] renderers;

    public string displayName = "PLAYER";

    public Bounds GetWorldBounds()
    {
        if (renderers == null || renderers.Length == 0)
            renderers = GetComponentsInChildren<Renderer>();

        bool found = false;
        Bounds result = new Bounds(transform.position, Vector3.zero);
        foreach (Renderer r in renderers)
        {
            if (r == null || !r.enabled) continue;
            if (!found) { result = r.bounds; found = true; }
            else result.Encapsulate(r.bounds);
        }
        return found ? result : new Bounds(transform.position, Vector3.one);
    }
}
