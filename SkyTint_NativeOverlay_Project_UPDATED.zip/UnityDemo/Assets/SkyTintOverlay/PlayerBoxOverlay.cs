using UnityEngine;

/// <summary>
/// Red screen-space boxes for PlayerBoxTarget objects in your own Unity scene.
/// Uses Unity scene objects and Renderer.bounds; it does not read process memory.
/// </summary>
public sealed class PlayerBoxOverlay : MonoBehaviour
{
    public Camera targetCamera;
    public bool boxesEnabled = true;
    public bool menuVisible = true;
    public Color boxColor = new Color(1f, 0.12f, 0.18f, 1f);
    [Range(1f, 6f)] public float lineThickness = 2f;
    public bool showLabels = true;

    private Texture2D pixel;
    private GUIStyle labelStyle;
    private PlayerBoxTarget[] targets;

    private void Awake()
    {
        if (targetCamera == null) targetCamera = Camera.main;
        pixel = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        pixel.SetPixel(0, 0, Color.white);
        pixel.Apply();
        labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter
        };
        labelStyle.normal.textColor = boxColor;
        RefreshTargets();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1)) menuVisible = !menuVisible;
        if (Input.GetKeyDown(KeyCode.F2)) boxesEnabled = !boxesEnabled;
    }

    public void RefreshTargets()
    {
#if UNITY_2023_1_OR_NEWER
        targets = FindObjectsByType<PlayerBoxTarget>(FindObjectsSortMode.None);
#else
        targets = FindObjectsOfType<PlayerBoxTarget>();
#endif
    }

    private void OnGUI()
    {
        if (boxesEnabled && targetCamera != null && targets != null)
        {
            Color old = GUI.color;
            GUI.color = boxColor;
            foreach (PlayerBoxTarget target in targets)
            {
                if (target == null || !target.isActiveAndEnabled) continue;
                DrawTarget(target);
            }
            GUI.color = old;
        }

        if (!menuVisible) return;
        const float w = 220f;
        GUI.Box(new Rect(14, 14, w, 116), "SKYTINT  /  RED");
        GUI.color = boxColor;
        if (GUI.Button(new Rect(26, 44, w - 24, 28), boxesEnabled ? "PLAYER BOXES: ON" : "PLAYER BOXES: OFF"))
            boxesEnabled = !boxesEnabled;
        if (GUI.Button(new Rect(26, 76, w - 24, 28), "HIDE MENU  [F1]"))
            menuVisible = false;
        GUI.color = Color.white;
        GUI.Label(new Rect(18, 134, w, 22), "F1: menu   F2: boxes");
    }

    private void DrawTarget(PlayerBoxTarget target)
    {
        Bounds b = target.GetWorldBounds();
        Vector3 c = b.center;
        Vector3 e = b.extents;
        Vector3[] corners = new Vector3[8];
        int i = 0;
        for (int x = -1; x <= 1; x += 2)
        for (int y = -1; y <= 1; y += 2)
        for (int z = -1; z <= 1; z += 2)
            corners[i++] = targetCamera.WorldToScreenPoint(c + Vector3.Scale(e, new Vector3(x, y, z)));

        float minX = float.PositiveInfinity, minY = float.PositiveInfinity;
        float maxX = float.NegativeInfinity, maxY = float.NegativeInfinity;
        bool anyInFront = false;
        foreach (Vector3 p in corners)
        {
            if (p.z <= 0) continue;
            anyInFront = true;
            minX = Mathf.Min(minX, p.x); maxX = Mathf.Max(maxX, p.x);
            minY = Mathf.Min(minY, p.y); maxY = Mathf.Max(maxY, p.y);
        }
        if (!anyInFront) return;
        float x0 = minX, y0 = Screen.height - maxY;
        float width = maxX - minX, height = maxY - minY;
        if (width < 2 || height < 2) return;
        DrawRect(new Rect(x0, y0, width, lineThickness));
        DrawRect(new Rect(x0, y0 + height - lineThickness, width, lineThickness));
        DrawRect(new Rect(x0, y0, lineThickness, height));
        DrawRect(new Rect(x0 + width - lineThickness, y0, lineThickness, height));
        if (showLabels)
        {
            labelStyle.normal.textColor = boxColor;
            GUI.Label(new Rect(x0, y0 - 22, width, 20), target.displayName, labelStyle);
        }
    }

    private void DrawRect(Rect rect)
    {
        GUI.DrawTexture(rect, pixel);
    }

    private void OnDestroy()
    {
        if (pixel != null) Destroy(pixel);
    }
}
