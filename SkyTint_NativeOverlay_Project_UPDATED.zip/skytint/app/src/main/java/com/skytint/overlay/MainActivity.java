package com.skytint.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22),dp(26),dp(22),dp(22)); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(Color.rgb(18,12,14));
        TextView title = new TextView(this); title.setText("SKYTINT  /  RED EDITION"); title.setTextColor(Color.rgb(255,65,75)); title.setTextSize(23); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,dp(58)));
        TextView desc = new TextView(this); desc.setText("Нативная плавающая панель\nКрасная тема • кнопка открытия/закрытия"); desc.setTextColor(Color.LTGRAY); desc.setGravity(Gravity.CENTER); desc.setTextSize(14); root.addView(desc,new LinearLayout.LayoutParams(-1,dp(64)));
        Button start = button("ЗАПУСТИТЬ ПАНЕЛЬ"); start.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); } else { startService(new Intent(this,OverlayService.class)); finish(); } }); root.addView(start,layout());
        Button stop = button("ЗАКРЫТЬ ПАНЕЛЬ"); stop.setOnClickListener(v -> stopService(new Intent(this,OverlayService.class))); root.addView(stop,layout());
        TextView note = new TextView(this); note.setText("Меню меняет только собственный интерфейс. Чтение памяти сторонней игры и ESP не включены."); note.setTextColor(Color.GRAY); note.setTextSize(12); note.setGravity(Gravity.CENTER); note.setPadding(0,dp(20),0,0); root.addView(note,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }
    private LinearLayout.LayoutParams layout(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50)); p.setMargins(0,dp(8),0,dp(8)); return p; }
    private Button button(String text){ Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,25,40))); return b; }
}
