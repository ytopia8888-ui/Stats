package com.skytint.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm; private WindowManager.LayoutParams bubbleParams, panelParams; private TextView bubble; private LinearLayout panel; private boolean panelShown=false;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); createBubble(); showPanel();}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.rgb(255,65,75));return d;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
    private WindowManager.LayoutParams params(int w,int h,int x,int y){int type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.START;p.x=x;p.y=y;return p;}
    private void createBubble(){bubble=label("S",18,Color.WHITE);bubble.setTypeface(Typeface.DEFAULT,Typeface.BOLD);bubble.setBackground(bg(Color.rgb(195,18,38),28));bubbleParams=params(dp(52),dp(52),dp(14),dp(180));bubble.setOnClickListener(v->{if(panelShown)hidePanel();else showPanel();});drag(bubble,bubbleParams);wm.addView(bubble,bubbleParams);}
    private void showPanel(){if(panelShown)return;panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(12),dp(10),dp(12),dp(10));panel.setBackground(bg(Color.rgb(24,15,18),18));
        TextView head=label("SKYTINT  •  RED",16,Color.rgb(255,65,75));head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.addView(head,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView hint=label("Плавающее меню",12,Color.LTGRAY);panel.addView(hint,new LinearLayout.LayoutParams(-1,dp(28)));
        addRow("КРАСНЫЙ АКЦЕНТ  ✓",Color.rgb(255,45,60)); addRow("СВЕРНУТЬ  −",Color.rgb(145,20,35)); addRow("ЗАКРЫТЬ  ×",Color.rgb(90,25,35));
        panelParams=params(dp(240),-2,dp(76),dp(180));drag(panel,panelParams);wm.addView(panel,panelParams);panelShown=true;}
    private void addRow(String text,int color){TextView t=label(text,13,Color.WHITE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setBackground(bg(color,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(42));p.setMargins(0,dp(4),0,dp(4));panel.addView(t,p);t.setOnClickListener(v->{if(text.startsWith("СВЕРНУТЬ"))hidePanel();else if(text.startsWith("ЗАКРЫТЬ"))stopSelf();});}
    private void hidePanel(){if(panelShown&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panelShown=false;panel=null;}}
    private void drag(View v,WindowManager.LayoutParams p){v.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;public boolean onTouch(View view,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;moved=false;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){int dx=(int)(e.getRawX()-sx),dy=(int)(e.getRawY()-sy);if(Math.abs(dx)+Math.abs(dy)>dp(5))moved=true;p.x=ox+dx;p.y=oy+dy;try{wm.updateViewLayout(v,p);}catch(Exception ignored){}return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(!moved&&v==bubble){if(panelShown)hidePanel();else showPanel();}return true;}return false;}});}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_NOT_STICKY;}
    @Override public void onDestroy(){hidePanel();if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
