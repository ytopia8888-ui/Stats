# SkyTint Native Overlay — Red Edition

Native Android Java overlay. It includes a red-themed floating launcher bubble, a movable panel, collapse/reopen, and close controls. It does not read third-party game memory or implement ESP/cheat tracking. The menu styling is UI-only; it does not change the Unity game's sky.

Build with Android Gradle Plugin 8.7.3 and JDK 17. In the app, grant “Display over other apps” permission, then tap “ЗАПУСТИТЬ ПАНЕЛЬ”. Tap the red `S` bubble to hide/show the panel. To remove the overlay, use “ЗАКРЫТЬ” or reopen the app and choose “ЗАКРЫТЬ ПАНЕЛЬ”.

Unity demo scripts are included separately in `UnityDemo/Assets/SkyTintOverlay` at the archive root. See `UnityDemo/README_RU.md` for setup.
