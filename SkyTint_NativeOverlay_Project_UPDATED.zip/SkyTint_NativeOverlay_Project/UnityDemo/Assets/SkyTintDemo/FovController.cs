using UnityEngine;

// For a Unity project you own or are authorized to modify.
// Attach this component to the active Camera. FOV is clamped to a safe range.
public class FovController : MonoBehaviour
{
    [Range(60f, 120f)] public float fieldOfView = 90f;
    private Camera targetCamera;

    private void Awake()
    {
        targetCamera = GetComponent<Camera>();
        if (targetCamera == null) targetCamera = Camera.main;
        ApplyFov();
    }

    private void OnValidate() => ApplyFov();

    public void SetFov(float value)
    {
        fieldOfView = Mathf.Clamp(value, 60f, 120f);
        ApplyFov();
    }

    private void ApplyFov()
    {
        if (targetCamera == null) targetCamera = GetComponent<Camera>();
        if (targetCamera != null && !targetCamera.orthographic)
            targetCamera.fieldOfView = Mathf.Clamp(fieldOfView, 60f, 120f);
    }
}
