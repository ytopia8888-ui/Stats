package com.skytint.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/** Native, movable interface overlay. Game-rendering changes are deliberately not claimed. */
public class OverlayService extends Service {
  private WindowManager wm;
  private View panel;
  private WindowManager.LayoutParams params;
  private LinearLayout body, shell;
  private TextView grip, status;
  private boolean collapsed = false;
  private int preset = 0, opacityIndex = 0, sizeIndex = 0, intensity = 75;
  private final int[] colors = {0xFF39A9FF,0xFFFF884D,0xFF9B6DFF,0xFF62E6B5,0xFF6577A8,0xFFFFD166};
  private final String[] names = {"Синий","Закат","Фиолетовый","Мята","Ночь","Золото"};
  private final int[] alphas = {0xF2,0xD9,0xB8};
  private final String[] alphaNames = {"95%","85%","72%"};
  private final int[] widths = {280,230,315};
  private final String[] widthNames = {"Обычный","Компактный","Широкий"};

  private boolean hasRoot() {
    Process p = null;
    try {
      p = Runtime.getRuntime().exec(new String[]{"su","-c","id"});
      BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
      String line = r.readLine();
      return p.waitFor() == 0 && line != null && line.contains("uid=0");
    } catch (Exception e) { return false; }
    finally { if (p != null) p.destroy(); }
  }
  @Override public IBinder onBind(Intent i) { return null; }
  @Override public int onStartCommand(Intent i, int flags, int startId) {
    if (!hasRoot()) { toast("SkyTint: требуется root-доступ"); stopSelf(); return START_NOT_STICKY; }
    if (!Settings.canDrawOverlays(this)) { toast("Разреши отображение поверх других приложений"); stopSelf(); return START_NOT_STICKY; }
    if (panel == null) showPanel();
    return START_NOT_STICKY;
  }
  private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
  private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
  private GradientDrawable shape(int color, int stroke) {
    GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(4));
    d.setStroke(dp(1),stroke); return d;
  }
  private TextView label(String value, int size, int color) {
    TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
    return t;
  }
  private Button action(String value) {
    Button b = new Button(this); b.setText(value); b.setAllCaps(false); b.setTextSize(13);
    b.setTextColor(Color.WHITE); b.setPadding(dp(8),dp(4),dp(8),dp(4));
    b.setMinHeight(dp(44)); b.setBackground(shape(0xFF263449,0xFF3D526E));
    if (android.os.Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
    return b;
  }
  private void section(LinearLayout target, String title) {
    TextView t=label(title,11,0xFF8EA8C8); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    t.setPadding(dp(2),dp(9),dp(2),dp(5)); target.addView(t);
  }
  private void addGap(LinearLayout target, int h) { View v=new View(this); target.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
  private void showPanel() {
    wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    shell=new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setPadding(dp(10),dp(9),dp(10),dp(7));
    shell.setBackground(shape((alphas[opacityIndex]<<24)|0x00111723,0xFF33445D));

    LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
    TextView mark=label("✦",24,colors[preset]); mark.setPadding(dp(3),0,dp(9),0); header.addView(mark);
    LinearLayout titleBox=new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
    TextView title=label("SKYTINT  •  v0.5",16,Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); titleBox.addView(title);
    TextView subtitle=label("RECTANGULAR UI  •  ROOT OVERLAY",9,0xFF93A7C3); titleBox.addView(subtitle);
    header.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
    Button close=action("×"); close.setTextSize(20); close.setMinWidth(dp(42));
    close.setOnClickListener(v->stopSelf()); header.addView(close,new LinearLayout.LayoutParams(dp(44),dp(42)));
    shell.addView(header);

    body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
    addGap(body,4);
    status=label("V0.5 ГОТОВ  •  ИЗМЕНЕНИЕ FOV НЕ ПОДКЛЮЧЕНО",9,0xFFFFD166);
    status.setPadding(dp(9),dp(9),dp(9),dp(9)); status.setBackground(shape(0xFF252B31,0xFF62573B)); body.addView(status);

    section(body,"ВИЗУАЛЬНЫЙ ПРОФИЛЬ НЕБА");
    TextView selected=label("Предпросмотр: "+names[preset],13,Color.WHITE); body.addView(selected);
    LinearLayout palette=new LinearLayout(this); palette.setGravity(Gravity.CENTER_VERTICAL);
    for (int i=0;i<colors.length;i++) {
      final int idx=i; Button swatch=action(names[i]); swatch.setTextSize(10); swatch.setMinHeight(dp(38));
      swatch.setBackground(shape(colors[i],0xFFDAE6F5));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1); lp.setMargins(dp(2),dp(4),dp(2),dp(2)); palette.addView(swatch,lp);
      swatch.setOnClickListener(v->{ preset=idx; selected.setText("Предпросмотр: "+names[preset]); selected.setTextColor(colors[preset]); markColor(); });
    }
    body.addView(palette);
    TextView intensityLabel=label("Интенсивность акцента: "+intensity+"%",12,0xFFDCE5F2); body.addView(intensityLabel);
    SeekBar intensityBar=new SeekBar(this); intensityBar.setMax(100); intensityBar.setProgress(intensity);
    if (android.os.Build.VERSION.SDK_INT>=21) intensityBar.setProgressTintList(android.content.res.ColorStateList.valueOf(colors[preset]));
    intensityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar s,int p,boolean user){intensity=p;intensityLabel.setText("Интенсивность акцента: "+p+"%");}
      public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
    }); body.addView(intensityBar);
    TextView hint=label("Это меняет оформление панели, а не графику Unity. В дампе RenderSettings содержит fogColor только для чтения; прямого готового переключателя skybox не найдено.",10,0xFF9EADC1);
    hint.setPadding(dp(2),dp(3),dp(2),dp(4)); body.addView(hint);

    section(body,"ОФОРМЛЕНИЕ ПАНЕЛИ");
    Button opacity=action("Прозрачность: "+alphaNames[opacityIndex]);
    opacity.setOnClickListener(v->{opacityIndex=(opacityIndex+1)%alphas.length; shell.setBackground(shape((alphas[opacityIndex]<<24)|0x00111723,0xFF33445D));opacity.setText("Прозрачность: "+alphaNames[opacityIndex]);}); body.addView(opacity);
    addGap(body,5);
    Button size=action("Размер: "+widthNames[sizeIndex]);
    size.setOnClickListener(v->{sizeIndex=(sizeIndex+1)%widths.length;params.width=dp(widths[sizeIndex]);size.setText("Размер: "+widthNames[sizeIndex]);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}}); body.addView(size);
    addGap(body,5);
    Button launch=action("▶   Запустить StandRise Rework");
    launch.setBackground(shape(0xFF176D62,0xFF3EC8AE)); launch.setOnClickListener(v->{
      if(!hasRoot()){toast("Нужен root-доступ");return;}
      try{Process p=Runtime.getRuntime().exec(new String[]{"su","-c","monkey -p com.standrise.game 1"});if(p.waitFor()!=0)toast("Не удалось запустить игру");}
      catch(Exception e){toast("Ошибка запуска игры");}
    }); body.addView(launch);
    shell.addView(body);

    grip=label("━━━━━━  СВЕРНУТЬ  ━━━━━━",11,0xFFDDE8F7); grip.setGravity(Gravity.CENTER);
    grip.setPadding(0,dp(9),0,dp(8)); grip.setBackground(shape(0xFF253247,0xFF354761));
    grip.setOnClickListener(v->{collapsed=!collapsed;body.setVisibility(collapsed?View.GONE:View.VISIBLE);grip.setText(collapsed?"━━━━━━  ОТКРЫТЬ МЕНЮ  ━━━━━━":"━━━━━━  СВЕРНУТЬ  ━━━━━━");});
    LinearLayout.LayoutParams glp=new LinearLayout.LayoutParams(-1,dp(40));glp.topMargin=dp(7);shell.addView(grip,glp);

    title.setOnTouchListener(new View.OnTouchListener(){float x,y;int sx,sy;
      public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();sx=params.x;sy=params.y;return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=sx+(int)(e.getRawX()-x);params.y=sy+(int)(e.getRawY()-y);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}return e.getAction()==MotionEvent.ACTION_UP;}});
    int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    params=new WindowManager.LayoutParams(dp(widths[sizeIndex]),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
    params.gravity=Gravity.TOP|Gravity.START;params.x=dp(12);params.y=dp(100);panel=shell;wm.addView(panel,params);
  }
  private void markColor() { if(panel instanceof LinearLayout) { /* accent is updated on next opening; no game process is touched */ } }
  @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}panel=null;super.onDestroy();}
}
