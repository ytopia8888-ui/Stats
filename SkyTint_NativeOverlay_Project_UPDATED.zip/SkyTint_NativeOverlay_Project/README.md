# SkyTint Native Overlay

Native Android Java overlay project for `com.standrise.game` (StandRise Rework). This is source code, not a prebuilt APK.

## Included
- Root check through `su` and Android overlay permission check
- Launch button for `com.standrise.game`
- Movable native panel with a bottom collapse/reopen strip
- Updated dark UI with color accents and six palette presets
- Accent intensity, panel opacity, and panel width controls
- No HTML/WebView and no injected native code

## Important: what the dump actually shows
`DUMP_ANALYSIS.md` summarizes the `dump.zip` review. The dumped Unity `RenderSettings` API exposes `fogColor` as a getter, with no setter shown, and the dump has no `Skybox` class or `set_skybox` entry. So the palette currently changes only the overlay's preview/accent. It does **not** recolor the game's sky. A real in-game change needs a verified runtime hook or a game-supported setting; this project does not pretend that one is implemented.

ESP, Chams, and No Recoil are not implemented. This project does not read player positions, alter weapon behavior, or inject into the game.

## Build APK with GitHub Actions
1. Extract this project into a GitHub repository so `settings.gradle` is at the repository root, or keep the `SkyTint_NativeOverlay_Project` directory and use the workflow included here.
2. Open **Actions → Build SkyTint APK → Run workflow**.
3. Download the `SkyTint-Native-Overlay-APK` artifact after the workflow succeeds.
4. Install the debug APK, grant **Display over other apps**, and approve the root prompt in Magisk.

The workflow generates a Gradle wrapper in CI; a wrapper is not bundled here.
