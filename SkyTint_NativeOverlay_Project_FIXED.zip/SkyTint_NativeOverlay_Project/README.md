# SkyTint Native Overlay

Android Java project for a movable native overlay panel. No HTML is used.

## Build on GitHub
1. Upload the contents of this project ZIP to the repository root (not the ZIP itself).
2. Commit and open Actions -> Build SkyTint APK.
3. Download the `SkyTint-Native-Overlay-APK` artifact.

## First run
Install the APK, open SkyTint Overlay, grant “Display over other apps”, then tap “Запустить панель”. The panel can be dragged by its header.

The included script `scripts/launch_skytint.sh` opens the overlay app and then launches `com.standrise.game`. Copy it to `/data/local/tmp/launch_skytint.sh` and run `su -c sh /data/local/tmp/launch_skytint.sh`.

**Limitations:** the color presets only update the overlay's demo profile/button color. They do not change Unity's in-game sky. Android overlay permission must be granted by the user once; root alone does not bypass that permission. The script does not grant overlay permission automatically.
