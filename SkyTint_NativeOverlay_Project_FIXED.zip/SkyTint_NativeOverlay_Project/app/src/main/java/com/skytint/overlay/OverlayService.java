package com.skytint.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
  private WindowManager wm; private View panel; private WindowManager.LayoutParams params; private int preset=0;
  private final int[] colors={0xFF39A9FF,0xFFFF884D,0xFF9B6DFF,0xFF62E6B5,0xFF26304D,0xFFFFD166};
  @Override public IBinder onBind(Intent i){return null;}
  @Override public void onCreate(){super.onCreate(); if(android.provider.Settings.canDrawOverlays(this)) showPanel();}
  private void showPanel(){
    wm=(WindowManager)getSystemService(WINDOW_SERVICE); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,14,18,14); box.setBackground(round(0xEE171D29));
    TextView head=new TextView(this); head.setText("SkyTint  •  ⋮"); head.setTextColor(Color.WHITE); head.setTextSize(18); head.setPadding(0,0,0,10); box.addView(head);
    TextView note=new TextView(this); note.setText("Профиль цвета (демо)"); note.setTextColor(0xFFD8E0EC); box.addView(note);
    Button color=new Button(this); color.setText("Цвет: Blue"); color.setOnClickListener(v->{preset=(preset+1)%colors.length; color.setText("Цвет: "+new String[]{"Blue","Sunset","Violet","Mint","Night","Gold"}[preset]); color.setBackgroundTintList(android.content.res.ColorStateList.valueOf(colors[preset]));}); box.addView(color);
    Button collapse=new Button(this); collapse.setText("Свернуть / развернуть"); collapse.setOnClickListener(v->{ for(int i=1;i<box.getChildCount();i++){View c=box.getChildAt(i); c.setVisibility(c.getVisibility()==View.GONE?View.VISIBLE:View.GONE);} }); box.addView(collapse);
    Button close=new Button(this); close.setText("Закрыть панель"); close.setOnClickListener(v->stopSelf()); box.addView(close);
    head.setOnTouchListener(new View.OnTouchListener(){float x,y; int sx,sy; public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();sx=params.x;sy=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=sx+(int)(e.getRawX()-x);params.y=sy+(int)(e.getRawY()-y);wm.updateViewLayout(panel,params);return true;}return true;}});
    int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;params.x=30;params.y=180;panel=box;wm.addView(panel,params);
  }
  private GradientDrawable round(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(24);d.setStroke(2,0xFF39465B);return d;}
  @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}super.onDestroy();}
}
