package com.skytint.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,32,28,24); root.setBackgroundColor(0xFF10131A);
    TextView title = new TextView(this); title.setText("SkyTint Native Overlay"); title.setTextSize(23); title.setTextColor(0xFFFFFFFF); root.addView(title);
    TextView info = new TextView(this); info.setText("Разреши отображение поверх других приложений, затем нажми запуск. После этого открой StandRise Rework."); info.setTextColor(0xFFD0D7E2); info.setPadding(0,20,0,20); root.addView(info);
    Button grant = new Button(this); grant.setText("Разрешить overlay"); grant.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }); root.addView(grant);
    Button start = new Button(this); start.setText("Запустить панель"); start.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) startService(new Intent(this, OverlayService.class)); else startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }); root.addView(start);
    setContentView(root);
  }
}
