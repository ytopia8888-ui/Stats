#!/system/bin/sh
# Launch SkyTint overlay app, then StandRise Rework.
PKG='com.standrise.game'
APP='com.skytint.overlay/.MainActivity'
am start -n "$APP" >/dev/null 2>&1
sleep 2
monkey -p "$PKG" 1 >/dev/null 2>&1
if [ $? -ne 0 ]; then
  am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p "$PKG"
fi
