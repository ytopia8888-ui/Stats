package com.skytint.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
  private TextView status;

  private boolean hasRoot() {
    Process p = null;
    try {
      p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
      BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
      String line = r.readLine();
      return p.waitFor() == 0 && line != null && line.contains("uid=0");
    } catch (Exception e) { return false; }
    finally { if (p != null) p.destroy(); }
  }

  private void showRootStatus() {
    status.setText(hasRoot()
      ? "Root-доступ подтверждён."
      : "Root не обнаружен. Разреши доступ приложению в Magisk.");
  }

  private void launchGameAndPanel() {
    if (!hasRoot()) {
      showRootStatus();
      Toast.makeText(this, "Нужен root-доступ (su)", Toast.LENGTH_LONG).show();
      return;
    }
    if (!Settings.canDrawOverlays(this)) {
      startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:" + getPackageName())));
      status.setText("Выдай разрешение «Поверх других приложений», затем нажми запуск ещё раз.");
      return;
    }
    try {
      startService(new Intent(this, OverlayService.class));
      Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "monkey -p com.standrise.game 1"});
      int result = p.waitFor();
      status.setText(result == 0
        ? "Панель запущена. Открываю StandRise Rework."
        : "Не удалось запустить com.standrise.game. Проверь, установлена ли игра.");
    } catch (Exception e) {
      status.setText("Ошибка запуска: " + e.getMessage());
    }
  }

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(28, 28, 28, 24);
    root.setBackgroundColor(0xFF10131A);

    TextView title = new TextView(this);
    title.setText("SkyTint Native Overlay");
    title.setTextSize(23);
    title.setTextColor(0xFFFFFFFF);
    root.addView(title);

    status = new TextView(this);
    status.setTextColor(0xFFD0D7E2);
    status.setPadding(0, 16, 0, 18);
    root.addView(status);

    Button check = new Button(this);
    check.setText("Проверить Root");
    check.setOnClickListener(v -> showRootStatus());
    root.addView(check);

    Button overlayPermission = new Button(this);
    overlayPermission.setText("Разрешить панель поверх игры");
    overlayPermission.setOnClickListener(v -> {
      if (!Settings.canDrawOverlays(this))
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())));
      else Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show();
    });
    root.addView(overlayPermission);

    Button launch = new Button(this);
    launch.setText("Запустить StandRise Rework");
    launch.setOnClickListener(v -> launchGameAndPanel());
    root.addView(launch);

    Button close = new Button(this);
    close.setText("Закрыть приложение");
    close.setOnClickListener(v -> finishAndRemoveTask());
    root.addView(close);

    setContentView(root);
    showRootStatus();
  }
}
