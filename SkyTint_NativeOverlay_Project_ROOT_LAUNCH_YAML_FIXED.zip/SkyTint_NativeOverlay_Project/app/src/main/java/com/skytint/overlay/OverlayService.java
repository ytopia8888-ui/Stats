package com.skytint.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class OverlayService extends Service {
  private WindowManager wm;
  private View panel;
  private WindowManager.LayoutParams params;
  private boolean collapsed = false;
  private int preset = 0;
  private final int[] colors = {0xFF39A9FF,0xFFFF884D,0xFF9B6DFF,0xFF62E6B5,0xFF26304D,0xFFFFD166};
  private final String[] names = {"Blue","Sunset","Violet","Mint","Night","Gold"};

  private boolean hasRoot() {
    Process p = null;
    try {
      p = Runtime.getRuntime().exec(new String[]{"su","-c","id"});
      BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
      String line = r.readLine();
      return p.waitFor() == 0 && line != null && line.contains("uid=0");
    } catch (Exception e) { return false; }
    finally { if (p != null) p.destroy(); }
  }

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (!hasRoot()) {
      Toast.makeText(this, "SkyTint: требуется root-доступ", Toast.LENGTH_LONG).show();
      stopSelf();
      return START_NOT_STICKY;
    }
    if (android.provider.Settings.canDrawOverlays(this) && panel == null) showPanel();
    return START_NOT_STICKY;
  }

  private void showPanel() {
    wm = (WindowManager)getSystemService(WINDOW_SERVICE);
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(14,12,14,12);
    box.setBackground(round(0xEE171D29));

    LinearLayout top = new LinearLayout(this);
    top.setGravity(Gravity.CENTER_VERTICAL);
    TextView head = new TextView(this);
    head.setText("SkyTint  •  перетащи");
    head.setTextColor(Color.WHITE);
    head.setTextSize(17);
    top.addView(head, new LinearLayout.LayoutParams(0, -2, 1));
    Button close = new Button(this);
    close.setText("×");
    close.setOnClickListener(v -> stopSelf());
    top.addView(close);
    box.addView(top);

    TextView note = new TextView(this);
    note.setText("Демо: выбор цвета пока не меняет небо Unity");
    note.setTextColor(0xFFD8E0EC);
    note.setPadding(0,6,0,6);
    box.addView(note);

    Button color = new Button(this);
    color.setText("Цвет: " + names[preset]);
    color.setBackgroundTintList(android.content.res.ColorStateList.valueOf(colors[preset]));
    color.setOnClickListener(v -> {
      preset = (preset + 1) % colors.length;
      color.setText("Цвет: " + names[preset]);
      color.setBackgroundTintList(android.content.res.ColorStateList.valueOf(colors[preset]));
    });
    box.addView(color);

    Button collapse = new Button(this);
    collapse.setText("Свернуть");
    collapse.setOnClickListener(v -> {
      collapsed = !collapsed;
      for (int i = 1; i < box.getChildCount(); i++)
        box.getChildAt(i).setVisibility(collapsed ? View.GONE : View.VISIBLE);
      collapse.setText(collapsed ? "Развернуть" : "Свернуть");
    });
    box.addView(collapse);

    Button launchGame = new Button(this);
    launchGame.setText("Открыть StandRise Rework");
    launchGame.setOnClickListener(v -> {
      if (!hasRoot()) {
        Toast.makeText(this, "Нужен root-доступ", Toast.LENGTH_LONG).show();
        return;
      }
      try {
        Process p = Runtime.getRuntime().exec(new String[]{"su","-c","monkey -p com.standrise.game 1"});
        if (p.waitFor() != 0) Toast.makeText(this, "Не удалось запустить игру", Toast.LENGTH_LONG).show();
      } catch (Exception e) {
        Toast.makeText(this, "Ошибка запуска игры", Toast.LENGTH_LONG).show();
      }
    });
    box.addView(launchGame);

    head.setOnTouchListener(new View.OnTouchListener() {
      float x, y; int sx, sy;
      public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) { x=e.getRawX(); y=e.getRawY(); sx=params.x; sy=params.y; return true; }
        if (e.getAction() == MotionEvent.ACTION_MOVE) { params.x=sx+(int)(e.getRawX()-x); params.y=sy+(int)(e.getRawY()-y); wm.updateViewLayout(panel,params); return true; }
        return true;
      }
    });

    int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    params.gravity = Gravity.TOP | Gravity.START;
    params.x = 30; params.y = 180;
    panel = box;
    wm.addView(panel, params);
  }

  private GradientDrawable round(int c) {
    GradientDrawable d = new GradientDrawable(); d.setColor(c); d.setCornerRadius(24); d.setStroke(2,0xFF39465B); return d;
  }

  @Override public void onDestroy() {
    if (wm != null && panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
    panel = null;
    super.onDestroy();
  }
}
