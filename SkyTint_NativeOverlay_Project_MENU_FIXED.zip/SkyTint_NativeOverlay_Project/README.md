# SkyTint Native Overlay — menu build

Native Android Java overlay project for StandRise Rework (`com.standrise.game`).

## Included
- Root check via `su`
- Overlay permission flow
- Launch game button
- Draggable floating panel
- Bottom grip to collapse/expand the menu body
- Panel color, opacity, and size controls
- ESP and Chams demo toggles for interface testing

## Important limitation
The ESP and Chams buttons are UI-only demo switches. They do **not** read game memory, highlight players, change Unity rendering, or provide an in-game ESP/chams feature. No recoil or game-mechanics modification is included.

## Build
Push the project to GitHub and run **Actions → Build SkyTint APK**. The workflow finds the project in the repository or extracts a project ZIP, then builds `assembleDebug` and uploads the APK as an artifact.

On the phone, grant SkyTint the Android “Display over other apps” permission and approve the `su` request in Magisk when prompted.
