package com.skytint.overlay;

import android.app.Service;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class OverlayService extends Service {
  private WindowManager wm;
  private View panel;
  private WindowManager.LayoutParams params;
  private LinearLayout menuBody;
  private boolean collapsed = false;
  private int preset = 0;
  private int opacityIndex = 0;
  private int sizeIndex = 0;
  private final int[] colors = {0xFF39A9FF,0xFFFF884D,0xFF9B6DFF,0xFF62E6B5,0xFF26304D,0xFFFFD166};
  private final String[] names = {"Синий","Закат","Фиолетовый","Мята","Ночь","Золото"};
  private final int[] panelAlphas = {0xEE, 0xCC, 0xAA};
  private final String[] opacityNames = {"100%","80%","65%"};
  private final int[] widthsDp = {260, 220, 300};
  private final String[] sizeNames = {"Обычный","Компактный","Широкий"};

  private boolean hasRoot() {
    Process p = null;
    try {
      p = Runtime.getRuntime().exec(new String[]{"su","-c","id"});
      BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
      String line = r.readLine();
      return p.waitFor() == 0 && line != null && line.contains("uid=0");
    } catch (Exception e) { return false; }
    finally { if (p != null) p.destroy(); }
  }

  @Override public IBinder onBind(Intent i) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (!hasRoot()) {
      Toast.makeText(this, "SkyTint: требуется root-доступ", Toast.LENGTH_LONG).show();
      stopSelf();
      return START_NOT_STICKY;
    }
    if (!android.provider.Settings.canDrawOverlays(this)) {
      Toast.makeText(this, "Разреши отображение поверх других приложений", Toast.LENGTH_LONG).show();
      stopSelf();
      return START_NOT_STICKY;
    }
    if (panel == null) showPanel();
    return START_NOT_STICKY;
  }

  private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

  private TextView text(String value, int size) {
    TextView t = new TextView(this);
    t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
    return t;
  }

  private Button button(String value) {
    Button b = new Button(this);
    b.setText(value);
    b.setAllCaps(false);
    return b;
  }

  private void showPanel() {
    wm = (WindowManager)getSystemService(WINDOW_SERVICE);
    LinearLayout box = new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(dp(10), dp(8), dp(10), dp(5));
    box.setBackground(round((panelAlphas[opacityIndex] << 24) | 0x00171D29));

    LinearLayout top = new LinearLayout(this);
    top.setGravity(Gravity.CENTER_VERTICAL);
    TextView head = text("SkyTint  •  перетащи", 16);
    top.addView(head, new LinearLayout.LayoutParams(0, -2, 1));
    Button close = button("×");
    close.setMinWidth(dp(42));
    close.setOnClickListener(v -> stopSelf());
    top.addView(close, new LinearLayout.LayoutParams(dp(46), dp(44)));
    box.addView(top);

    menuBody = new LinearLayout(this);
    menuBody.setOrientation(LinearLayout.VERTICAL);
    TextView note = text("Настройки интерфейса. Цвета не меняют графику Unity; функции no recoil и chams не включены.", 12);
    note.setTextColor(0xFFD8E0EC);
    note.setPadding(dp(2), dp(5), dp(2), dp(5));
    menuBody.addView(note);

    // Visual demo switches only: they do not read or modify game memory/rendering.
    final boolean[] espEnabled = {false};
    final boolean[] chamsEnabled = {false};
    Button esp = button("ESP: ВЫКЛ (демо)");
    esp.setOnClickListener(v -> {
      espEnabled[0] = !espEnabled[0];
      esp.setText("ESP: " + (espEnabled[0] ? "ВКЛ (демо)" : "ВЫКЛ (демо)"));
      Toast.makeText(this, "Демо-переключатель: ESP не подключён к рендерингу игры", Toast.LENGTH_SHORT).show();
    });
    menuBody.addView(esp);

    Button chams = button("Chams: ВЫКЛ (демо)");
    chams.setOnClickListener(v -> {
      chamsEnabled[0] = !chamsEnabled[0];
      chams.setText("Chams: " + (chamsEnabled[0] ? "ВКЛ (демо)" : "ВЫКЛ (демо)"));
      Toast.makeText(this, "Демо-переключатель: Chams не меняет графику игры", Toast.LENGTH_SHORT).show();
    });
    menuBody.addView(chams);

    Button color = button("Цвет панели: " + names[preset]);
    color.setBackgroundTintList(ColorStateList.valueOf(colors[preset]));
    color.setOnClickListener(v -> {
      preset = (preset + 1) % colors.length;
      color.setText("Цвет панели: " + names[preset]);
      color.setBackgroundTintList(ColorStateList.valueOf(colors[preset]));
    });
    menuBody.addView(color);

    Button opacity = button("Прозрачность: " + opacityNames[opacityIndex]);
    opacity.setOnClickListener(v -> {
      opacityIndex = (opacityIndex + 1) % panelAlphas.length;
      box.setBackground(round((panelAlphas[opacityIndex] << 24) | 0x00171D29));
      opacity.setText("Прозрачность: " + opacityNames[opacityIndex]);
    });
    menuBody.addView(opacity);

    Button size = button("Размер: " + sizeNames[sizeIndex]);
    size.setOnClickListener(v -> {
      sizeIndex = (sizeIndex + 1) % widthsDp.length;
      params.width = dp(widthsDp[sizeIndex]);
      size.setText("Размер: " + sizeNames[sizeIndex]);
      try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
    });
    menuBody.addView(size);

    Button launchGame = button("Открыть StandRise Rework");
    launchGame.setOnClickListener(v -> {
      if (!hasRoot()) {
        Toast.makeText(this, "Нужен root-доступ", Toast.LENGTH_LONG).show();
        return;
      }
      try {
        Process p = Runtime.getRuntime().exec(new String[]{"su","-c","monkey -p com.standrise.game 1"});
        if (p.waitFor() != 0) Toast.makeText(this, "Не удалось запустить игру", Toast.LENGTH_LONG).show();
      } catch (Exception e) {
        Toast.makeText(this, "Ошибка запуска игры", Toast.LENGTH_LONG).show();
      }
    });
    menuBody.addView(launchGame);
    box.addView(menuBody);

    // This bottom grip remains visible while collapsed. Tap it to hide/show the menu body.
    TextView grip = text("━━━━━━  SkyTint  ━━━━━━", 12);
    grip.setGravity(Gravity.CENTER);
    grip.setPadding(0, dp(8), 0, dp(7));
    grip.setBackground(round(0xFF303B4D));
    grip.setOnClickListener(v -> {
      collapsed = !collapsed;
      menuBody.setVisibility(collapsed ? View.GONE : View.VISIBLE);
      grip.setText(collapsed ? "━━━━━━  ОТКРЫТЬ МЕНЮ  ━━━━━━" : "━━━━━━  SkyTint  ━━━━━━");
    });
    box.addView(grip, new LinearLayout.LayoutParams(-1, dp(38)));

    head.setOnTouchListener(new View.OnTouchListener() {
      float x, y; int sx, sy;
      @Override public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) { x=e.getRawX(); y=e.getRawY(); sx=params.x; sy=params.y; return true; }
        if (e.getAction() == MotionEvent.ACTION_MOVE) {
          params.x=sx+(int)(e.getRawX()-x); params.y=sy+(int)(e.getRawY()-y);
          try { wm.updateViewLayout(panel,params); } catch (Exception ignored) {}
          return true;
        }
        return e.getAction() == MotionEvent.ACTION_UP;
      }
    });

    int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
    params = new WindowManager.LayoutParams(dp(widthsDp[sizeIndex]), WindowManager.LayoutParams.WRAP_CONTENT, type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
    params.gravity = Gravity.TOP | Gravity.START;
    params.x = dp(16); params.y = dp(120);
    panel = box;
    wm.addView(panel, params);
  }

  private GradientDrawable round(int c) {
    GradientDrawable d = new GradientDrawable();
    d.setColor(c); d.setCornerRadius(dp(16)); d.setStroke(dp(1),0xFF39465B);
    return d;
  }

  @Override public void onDestroy() {
    if (wm != null && panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
    panel = null;
    super.onDestroy();
  }
}
